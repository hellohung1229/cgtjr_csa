/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package cgtjr.academics.elctrclengnrng.cv.sfs;

/**
 *
 * @author clayton g thomas jr
 */
public class PIC
{
   public int type;
   public int maxX,maxY;
   public int image[];
}
