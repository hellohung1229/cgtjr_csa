package cgtjr.academics.elctrclengnrng.cv.sfs.gui.pnl;

import cgtjr.academics.elctrclengnrng.cv.sfs.SFSTSActn;
import cgtjr.academics.general.GeneralCanvas;
import cgtjr.academics.general.GeneralPanel;
import cgtjr.academics.general.LabStation;
import cgtjr.academics.general.SceneRoot;
import java.awt.Dimension;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import javax.swing.*;

public class SFSPnl extends GeneralPanel implements ActionListener {

   private SceneRoot scnRt;    
   private GeneralCanvas theGeneralCanvas;
   
   private JApplet cmpnntPanel;
   
   private JEditorPane outputJEditorPane;
   private JButton resetBttn;
   private JButton resetBttn2;
   private JButton enterBttn;

   private JLabel albedoLbl;
   private JLabel tiltLbl;

   private JLabel slantLbl;
   private JLabel brightnessLbl;
   private JLabel brghtAvgSqrdLbl;

   private JLabel blank1Lbl;
   private JLabel blank2Lbl;
   private JLabel blank3Lbl;
   private JLabel blank4Lbl;
   private JLabel blank5Lbl;
   private JLabel blank6Lbl;

   private JTextField albedoJTF;
   private JTextField tiltJTF;

   private JTextField slantJTF;
   private JTextField brightnessJTF;
   private JTextField brghtAvgSqrdJTF;

   //private JChoice eqtnChoice;
   private JLabel eqtnLbl;

   //myLabWndwPnl
           
   public SFSPnl(SceneRoot myScnRt)
   {
      super();
      scnRt = myScnRt;
      //addComponentsToPane();
   }
   public SFSPnl(SceneRoot myScnRt,JApplet myCmpntPanel)
   {
      super();
      scnRt = myScnRt;
      cmpnntPanel = myCmpntPanel;
      //addComponentsToPane();
   }   
   public SFSPnl(GeneralCanvas myGeneralCanvas)
   {
      super();
      theGeneralCanvas = myGeneralCanvas;
      //addComponentsToPane();
   }
   public JPanel addComponentsToPane() 
   {
      JPanel aJPanel = new JPanel();
      aJPanel.setLayout(new BoxLayout(aJPanel, BoxLayout.X_AXIS));

      /*
      eqtnLbl = new JLabel("EQUATION");
      eqtnLbl.setMaximumSize(new Dimension(80,20));
      eqtnLbl.setPreferredSize(new Dimension(80,20));

      eqtnChoice = EqtnChoice.rtrvChoices();
      */
      resetBttn = new JButton("RESET");
      resetBttn.setName("reset");
      resetBttn.addActionListener(this);
      resetBttn.setMaximumSize(new Dimension(80,20));
      resetBttn.setPreferredSize(new Dimension(80,20));

      enterBttn = new JButton("CALCULATE");
      enterBttn.setName("enter");
      enterBttn.addActionListener(this);
      enterBttn.setMaximumSize(new Dimension(80,20));
      enterBttn.setPreferredSize(new Dimension(80,20));

      blank1Lbl = new JLabel(" ");
      blank1Lbl.setMaximumSize(new Dimension(80,20));
      blank1Lbl.setPreferredSize(new Dimension(80,20));

      blank2Lbl = new JLabel(" ");
      blank2Lbl.setMaximumSize(new Dimension(80,20));
      blank2Lbl.setPreferredSize(new Dimension(80,20));

      blank3Lbl = new JLabel(" ");
      blank3Lbl.setMaximumSize(new Dimension(80,20));
      blank3Lbl.setPreferredSize(new Dimension(80,20));

      blank4Lbl = new JLabel(" ");
      blank4Lbl.setMaximumSize(new Dimension(80,20));
      blank4Lbl.setPreferredSize(new Dimension(80,20));

      blank5Lbl = new JLabel(" ");
      blank5Lbl.setMaximumSize(new Dimension(80,20));
      blank5Lbl.setPreferredSize(new Dimension(80,20));

      blank6Lbl = new JLabel(" ");
      blank6Lbl.setMaximumSize(new Dimension(80,20));
      blank6Lbl.setPreferredSize(new Dimension(80,20));

      albedoLbl = new JLabel("ALBEDO");
      albedoLbl.setMaximumSize(new Dimension(80,20));
      albedoLbl.setPreferredSize(new Dimension(80,20));

      tiltLbl = new JLabel("TILT");
      tiltLbl.setMaximumSize(new Dimension(80,20));
      tiltLbl.setPreferredSize(new Dimension(80,20));

      slantLbl = new JLabel("SLANT");
      slantLbl.setMaximumSize(new Dimension(80,20));
      slantLbl.setPreferredSize(new Dimension(80,20));

      brightnessLbl = new JLabel("BRIGHTNESS");
      brightnessLbl.setMaximumSize(new Dimension(80,20));
      brightnessLbl.setPreferredSize(new Dimension(80,20));

      brghtAvgSqrdLbl = new JLabel("BRIGHT. AVG. SQRD.");
      brghtAvgSqrdLbl.setMaximumSize(new Dimension(80,20));
      brghtAvgSqrdLbl.setPreferredSize(new Dimension(80,20));
      brghtAvgSqrdLbl.setName("intensity");

      albedoJTF = new JTextField("8");
      albedoJTF.setMaximumSize(new Dimension(80,20));
      albedoJTF.setPreferredSize(new Dimension(80,20));
      albedoJTF.setName("imagewidth");

      tiltJTF = new JTextField("8");
      tiltJTF.setMaximumSize(new Dimension(80,20));
      tiltJTF.setPreferredSize(new Dimension(80,20));

      slantJTF = new JTextField(".5");
      slantJTF.setMaximumSize(new Dimension(80,20));
      slantJTF.setPreferredSize(new Dimension(80,20));

      brightnessJTF = new JTextField(".5");
      brightnessJTF.setMaximumSize(new Dimension(80,20));
      brightnessJTF.setPreferredSize(new Dimension(80,20));

      brghtAvgSqrdJTF = new JTextField(".4");
      brghtAvgSqrdJTF.setMaximumSize(new Dimension(80,20));
      brghtAvgSqrdJTF.setPreferredSize(new Dimension(80,20));

      JPanel leftJPanel = new JPanel();
      leftJPanel.setLayout(new BoxLayout(leftJPanel,BoxLayout.Y_AXIS));
      //leftJPanel.add(eqtnLbl);
      /*
      leftJPanel.add(blank5Lbl);
      leftJPanel.add(albedoLbl);
      leftJPanel.add(tiltLbl);
      leftJPanel.add(blank3Lbl);
      leftJPanel.add(slantLbl);
      leftJPanel.add(brightnessLbl);
      leftJPanel.add(brghtAvgSqrdLbl);
      */
      leftJPanel.add(blank1Lbl);
      leftJPanel.add(resetBttn);

      JPanel rightPanel = new JPanel();
      rightPanel.setLayout(new BoxLayout(rightPanel,BoxLayout.Y_AXIS));   
      //rightPanel.add(eqtnChoice);
      /*
      rightPanel.add(blank6Lbl);
      rightPanel.add(albedoJTF);
      rightPanel.add(tiltJTF);
      rightPanel.add(blank4Lbl);
      rightPanel.add(slantJTF);
      rightPanel.add(brightnessJTF);   
      rightPanel.add(brghtAvgSqrdJTF);
      */
      rightPanel.add(blank2Lbl);
      rightPanel.add(enterBttn);

      aJPanel.add(rightPanel);
      aJPanel.add(leftJPanel); 
      
      if(cmpnntPanel != null)
      {
          cmpnntPanel.add(aJPanel);
      }else{
         add(aJPanel);
      }
      return aJPanel;
   }
   public void actionPerformed(ActionEvent e) 
   {
      String cmd = e.getActionCommand();

      if(cmd.equals(enterBttn.getText()))
      {
         System.out.println("SFSPnl: test ...");
         HashMap aHashMap = new HashMap();
         TextField aTextField = LabStation.getFileTextField();
         String aFileName = aTextField.getText();
         System.out.println("SnthtcImgRdPnl: name = "+aFileName);
         aHashMap.put("filename",aFileName);
         SFSTSActn aSFSTSActn = new SFSTSActn(scnRt);
         aSFSTSActn.doAction(aHashMap);
      }
   }
   public void setOutputJEditorPane(JEditorPane myJEditorPane)
   {
      outputJEditorPane = myJEditorPane;
   }
}