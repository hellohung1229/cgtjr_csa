package cgtjr.academics.elctrclengnrng.cv.sfs.gui.app;

import cgtjr.academics.elctrclengnrng.cv.sfs.gui.tab.SFSTab;
import cgtjr.academics.general.SceneRoot;
import java.awt.Component;
import javax.swing.JApplet;

public class SFSApp {

    private SFSStation aSFSStation;

    public SFSApp() {
    }

    public Component crtUI() {
        SceneRoot aSceneRoot = new SceneRoot();
        aSFSStation = new SFSStation(aSceneRoot);

        SFSTab anSFSTab = new SFSTab(aSceneRoot);
        String anAppTabNm = anSFSTab.getClass().getName();

        aSFSStation.insertLabPanel(anAppTabNm, anSFSTab);
        aSFSStation.displayLabPanel(anAppTabNm);

        return aSFSStation;
    }
    
    public Component crtUI(JApplet myLabWndwPnl) {
        SceneRoot aSceneRoot = new SceneRoot();
        aSFSStation = new SFSStation(aSceneRoot, myLabWndwPnl);
        SFSTab anSFSTab = new SFSTab(aSceneRoot, myLabWndwPnl);
        String anAppTabNm = anSFSTab.getClass().getName();

        aSFSStation.insertLabPanel(anAppTabNm, anSFSTab);
        aSFSStation.displayLabPanel(anAppTabNm);
        return aSFSStation;
    }
}