package cgtjr.academics.elctrclengnrng.cv.sfs.gui.app;

import java.awt.BorderLayout;
import java.awt.Component;
import javax.swing.JApplet;

public class SFSApplt extends JApplet {

    public SFSApplt() {
    }
    public void init() {
        SFSApp aSFSApp = new SFSApp();
        Component aComponent = aSFSApp.crtUI(this);
        add(BorderLayout.CENTER, aComponent);
        setVisible(true);
    }
    public void destroy() {
    }
}