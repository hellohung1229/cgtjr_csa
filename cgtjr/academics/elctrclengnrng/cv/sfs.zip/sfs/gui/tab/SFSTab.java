package cgtjr.academics.elctrclengnrng.cv.sfs.gui.tab;

import cgtjr.academics.elctrclengnrng.cv.sfs.gui.pnl.SFSPnl;
import cgtjr.academics.general.LabTab;
import cgtjr.academics.general.SceneRoot;
import java.awt.GridLayout;
import javax.swing.*;

/**
 * GmtryTab is used as a container for various panels.  These panels
 * provide application interaction with the user interface and geometric 
 * objects.
 * @author clayton g thomas jr
 */
public class SFSTab extends LabTab {

    JEditorPane outputJEditorPane;
    SceneRoot scnRt;

    /**
     * Instantiates a GmtryTab (geometry tab), with a scene root (SceneRoot)
     * reference.
     * @param mySceneRoot
     */
    public SFSTab(SceneRoot mySceneRoot) {
        //setLayout(new GridLayout(1, 1));
        //setTabLayoutPolicy(JTabbedPane.SCROLL_TAB_LAYOUT);
        scnRt = mySceneRoot;
        //addChangeListener(new TbPnLstnr());
        addCmpnts();
    }

    /**
     * Instantiates a GmtryTab (geometry tab), with a scene root (SceneRoot)
     * reference.
     * @param mySceneRoot represents the scene root object
     * @param myLabWndwPnl Represents the applet container.
     */
    
    public SFSTab(SceneRoot mySceneRoot, JApplet myLabWndwPnl) {
        setLayout(new GridLayout(1, 1));
        //setTabLayoutPolicy(JTabbedPane.SCROLL_TAB_LAYOUT);
        scnRt = mySceneRoot;
        //addChangeListener(new TbPnLstnr());
        addCmpnts(myLabWndwPnl);
    }

    /**
     * The constructor instantiates the geometry tab object (GmtryTab) with
     * the scene root object (SceneRoot) and applet panel.
     * @param mySceneRoot represents the scene root object
     * @param myLabWndwPnl Represents the applet container.
     */
    /*
    public SFSTab(SceneRoot mySceneRoot, JEditorPane myJEditorPane) {
        setLayout(new GridLayout(1, 1));
        setTabLayoutPolicy(JTabbedPane.SCROLL_TAB_LAYOUT);
        scnRt = mySceneRoot;
        outputJEditorPane = myJEditorPane;
        addCmpnts();
    }*/

    /**
     * The constructor instantiates the geometry tab object (GmtryTab) with
     * the scene root object (SceneRoot) and applet panel.
     * @param mySceneRoot represents the scene root object (SceneRoot).
     * @param myJEditorPane represents the JEditorPane object.
     * @param myLabWndwPnl represents a reference to the applet container.
     */
    
    public SFSTab(SceneRoot mySceneRoot, JEditorPane myJEditorPane, JApplet myLabWndwPnl) {
        setLayout(new GridLayout(1, 1));
        setTabLayoutPolicy(JTabbedPane.SCROLL_TAB_LAYOUT);
        scnRt = mySceneRoot;
        outputJEditorPane = myJEditorPane;
        addCmpnts(myLabWndwPnl);
    }

    private void addCmpnts() {
        SFSPnl panell = new SFSPnl(scnRt);
        JPanel aJPanel = panell.addComponentsToPane();
        addPnlToTab(aJPanel, "SFS");
    }
    
    private void addCmpnts(JApplet myLabWndwPnl) {
        SFSPnl panell = new SFSPnl(scnRt, myLabWndwPnl);
        JPanel aJPanel = panell.addComponentsToPane();        
        addPnlToTab(aJPanel, "SFS");
    }

    private void addPnlToTab(JComponent myJComponent, String myInfo) {
        addTab(myInfo, null, myJComponent, myInfo);
        setTabLayoutPolicy(JTabbedPane.SCROLL_TAB_LAYOUT);
    }
}