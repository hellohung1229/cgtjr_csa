package cgtjr.academics.elctrclengnrng.cv.sfs;

import cgtjr.academics.chmstry.physical.PntSampler;
import cgtjr.academics.elctrclengnrng.cv.sfs.gui.EqtnSmplr;
import cgtjr.academics.elctrclengnrng.imgprcssng.ImageTool;
import cgtjr.academics.elctrclengnrng.imgprcssng.ThrshldImgBndry;
import cgtjr.academics.general.GeneralPnlActn;
import cgtjr.academics.general.SceneRoot;
import cgtjr.academics.math.geometry.*;
import cgtjr.academics.math.geometry.g3d.QuadG3D;
import java.awt.image.BufferedImage;
import java.util.HashMap;
import java.util.Vector;


public class SFSTSActn extends GeneralPnlActn
{
   private int outputData[];
   private SceneRoot scnRt;

   public SFSTSActn(SceneRoot myScnRt)
   {
      scnRt = myScnRt;
   }
   public void doAction(HashMap myHashMap)
   {
      String aFileName = (String)myHashMap.get("filename");
      BufferedImage myImage = ImageTool.rdImageFile(aFileName);
      int imageData[] = ImageTool.rtrv1DPxls(myImage);
      int maxX = myImage.getWidth(null);
      int maxY= myImage.getHeight(null);


      PntSampler aPntSampler = new PntSampler();
      ShapePnt aPadShape = new ShapePnt();
      aPadShape.setDeltaX(1f);
      aPadShape.setDeltaY(1f);
      aPadShape.setDeltaZ(1f);
      ThrshldImgBndry aThrshldImgBndry = new ThrshldImgBndry(imageData,maxX,maxY,0,0);      
      aPadShape.setBoundaryShape(aThrshldImgBndry);
      aPadShape.crtInitCoordinates(maxX/2,maxY/2,0,aPntSampler);      
      aPadShape.crtMeshByBndry(aPntSampler);

      
      int aHght = (int)aPadShape.cmptHeight();
      int aWdth = (int)aPadShape.cmptWidth();  
      int minX = (int)aPadShape.getXMin();
      int minY = (int)aPadShape.getYMin();
      System.out.println("SFSTSAction: max x= "+maxX+", max y = "+maxY);   
      System.out.println("SFSTSAction: width = "+aWdth+", height = "+aHght);
      System.out.println("SFSTSAction: minX = "+minX+", minY = "+minY);      
      
      BufferedImage anImage2 = myImage.getSubimage(minX, minY,aWdth,aHght);
      int imageData2[] = ImageTool.rtrv1DPxls(anImage2);      
      MeshShp aShape = new MeshShp(new DmnsnVar(0,0,0,0,0,0,aWdth,aHght,0,1,1,1));
      aShape.setDeltaX(1f);
      aShape.setDeltaY(1f);
      aShape.setDeltaZ(1f);

      SFSTS.process(anImage2);
      float z[][] = SFSTS.rtrvZn();
      outputData = SFSTS.rtrvPxlData();
      int aHeight = z.length;
      int aWidth = z[0].length;

      HghtSmplr aHghtSmplr = new HghtSmplr(z,aWdth,aHght);


      aPntSampler.insrtSampler(aHghtSmplr);
      aShape.setBoundaryShape(new ShpBndry(aWdth,aHght,0));
      Pnt aPoint1 = aShape.crtInitCoordinates(aPntSampler);

      aShape.crtMeshByBndry(aPntSampler);
      Vector myNodeVector = aShape.getNodes();

      ImgRdSmplr anImgRdSmplr = new ImgRdSmplr(imageData2,aWdth,aHght);      
      anImgRdSmplr.prcssNodes(myNodeVector);
      aHghtSmplr.updtHght(myNodeVector);

      EqtnSmplr aEqtnSmplr = new EqtnSmplr(aWdth,aHght);
      aEqtnSmplr.updtHght(myNodeVector);

      //LineG3D crdntLineG3D = new LineG3D(aShape);
      QuadG3D aQuadG3D = new QuadG3D(aShape);
      //HxhdrlG3D aHxhdrlG3D = new HxhdrlG3D(aShape);
      //scnRt.addShp3D(crdntLineG3D);
      scnRt.addShp3D(aQuadG3D);
   }
}