/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cgtjr.academics.elctrclengnrng.radiosity.gui.RadMode;

import java.util.ArrayList;

/**
 *
 * @author cgthomasjr
 */
public class RadVertex {
   private double x;
   private double y;
   private double z;
   
   public RadVertex(){
       
   }
   public RadVertex(double myX,double myY,double myZ){
       x = myX;
       y = myY;
       z = myZ;
   }
}
