/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cgtjr.academics.elctrclengnrng.radiosity.gui.RadMode;

import java.util.ArrayList;

/**
 *
 * @author cgthomasjr
 */
public class RadPatch {
   private double v1;
   private double v2;
   private double v3;
   private double v4;
           
   ArrayList theElementArrayList;
       
   public RadPatch(){
       theElementArrayList = new ArrayList();
   }
   public RadPatch(double myV1,double myV2,double myV3,double myV4){
       v1 = myV1;
       v2 = myV2;
       v3 = myV3;
       v4 = myV4;
       theElementArrayList = new ArrayList();
   }   
   public RadPatch(ArrayList myElementArrayList){
       theElementArrayList = myElementArrayList;
   }
   public void addElement(RadElement myRadElement){
       theElementArrayList.add(myRadElement);
   }

    public double getV1() {
        return v1;
    }

    public void setV1(double v1) {
        this.v1 = v1;
    }

    public double getV2() {
        return v2;
    }

    public void setV2(double v2) {
        this.v2 = v2;
    }

    public double getV3() {
        return v3;
    }

    public void setV3(double v3) {
        this.v3 = v3;
    }

    public double getV4() {
        return v4;
    }

    public void setV4(double v4) {
        this.v4 = v4;
    }   
}
