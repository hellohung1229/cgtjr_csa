package cgtjr.academics.elctrclengnrng.radiosity.gui.RadMode;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class File2Rad {

    private static URL URLBase;
    private String recordSection;
    
    private ArrayList vertexArrayList;
    private ArrayList surfaceArrayList;
    private ArrayList patchArrayList;
    private ArrayList elementArrayList;

    public File2Rad() {
        surfaceArrayList = new ArrayList();
        vertexArrayList = new ArrayList();
        patchArrayList = new ArrayList();
        elementArrayList = new ArrayList();
        recordSection = "";
    }

    public void readFile(String myFileName) {
        InputStream anInputStream = null;
        URL aURL = null;

        try {
            if ((myFileName != null && myFileName.toLowerCase().startsWith("http:"))
                    || (myFileName != null && myFileName.toLowerCase().startsWith("https:"))
                    || (myFileName != null && myFileName.toLowerCase().startsWith("jar:http:"))
                    || (myFileName != null && myFileName.toLowerCase().startsWith("ftp:"))
                    || (myFileName != null && myFileName.toLowerCase().startsWith("file:"))) {
                aURL = new URL(myFileName);
                anInputStream = aURL.openStream();
            } else if (URLBase != null) {
                aURL = new URL(URLBase, myFileName);
                anInputStream = aURL.openStream();
                //System.out.println("url = "+URLBase);
            } else {
                //FileInputStream aFileInputStream = new FileInputStream(myFileName);
                anInputStream = new FileInputStream(myFileName);
            }
            BufferedReader reader =
                    new BufferedReader(new InputStreamReader(anInputStream));
            String aLine = reader.readLine();
            while (aLine != null) {
                processRecord(aLine);
                aLine = reader.readLine();
            }
            anInputStream.close();
        } catch (Exception e) {
            System.out.println("Rad2File: message : " + e.getMessage());
            System.out.println("Rad2File: stacktrace : " + e.getStackTrace());
        }

    }

    public void processRecord(String myLine) {
        System.out.println("RadFile.processRecord(): " + myLine);

        if (myLine.toLowerCase().indexOf("end_entity") >= 0) {
            System.out.println("end entity section");
            recordSection = "end_entity";
        }else if (myLine.toLowerCase().indexOf("entity") >= 0) {
            System.out.println("start entity section");
            recordSection = "entity";
        } else if (myLine.toLowerCase().indexOf("end_vert") >= 0) {
            System.out.println("end vertex section");
            recordSection = "end_vertex";
        } else if (myLine.toLowerCase().indexOf("vertex") >= 0) {
            System.out.println("start vertex section");
            recordSection = "vertex";
        } else if (myLine.toLowerCase().indexOf("end_surf") >= 0) {
            System.out.println("end surface section");
            recordSection = "end_surf";
        } else if (myLine.toLowerCase().indexOf("surface") >= 0) {
            System.out.println("start surface section");
            recordSection = "surface";
        } else if (myLine.toLowerCase().indexOf("end_patch") >= 0) {
            System.out.println("end patch section");
            recordSection = "end_patch";
        } else if (myLine.toLowerCase().indexOf("patch") >= 0) {
            System.out.println("start patch section");
            recordSection = "patch";
        } else if (myLine.toLowerCase().indexOf("end_elem") >= 0) {
            System.out.println("end element section");
            recordSection = "end_patch";
        } else if (myLine.toLowerCase().indexOf("element") >= 0) {
            System.out.println("start element section");
            recordSection = "element";
        } else if (recordSection.equals("vertex")) {
            processVertex(myLine);
        } else if (recordSection.equals("surface")) {
            processSurface(myLine);
        } else if (recordSection.equals("patch")) {
            processPatch(myLine);
        } else if (recordSection.equals("element")) {
            processElement(myLine);
        } 
        if (recordSection.equals("end_entity")) {
            updteSrfcePatchElmnt();
        }
    }

    public void processVertex(String myLine) {
        StringTokenizer aStringTokenizer = new StringTokenizer(myLine);
        String aLeftB = aStringTokenizer.nextToken();
        String xCoord = aStringTokenizer.nextToken();
        String yCoord = aStringTokenizer.nextToken();
        String zCoord = aStringTokenizer.nextToken();
        String aRightB = aStringTokenizer.nextToken();

        System.out.println("vertex : " + xCoord + " " + yCoord + " " + zCoord);
        double x = Double.parseDouble(xCoord);
        double y = Double.parseDouble(yCoord);
        double z = Double.parseDouble(zCoord);
        RadVertex aRadVertex = new RadVertex(x, y, z);
        vertexArrayList.add(aRadVertex);
    }

    public void processSurface(String myLine) {
        StringTokenizer aStringTokenizer = new StringTokenizer(myLine);
        String aLeftB1 = aStringTokenizer.nextToken();
        String rrS = aStringTokenizer.nextToken();
        String rgS = aStringTokenizer.nextToken();
        String rbS = aStringTokenizer.nextToken();
        String aRightB1 = aStringTokenizer.nextToken();

        String aLeftB2 = aStringTokenizer.nextToken();
        String erS = aStringTokenizer.nextToken();
        String egS = aStringTokenizer.nextToken();
        String ebS = aStringTokenizer.nextToken();
        String aRightB2 = aStringTokenizer.nextToken();

        double rr = Double.parseDouble(rrS);
        double rg = Double.parseDouble(rgS);
        double rb = Double.parseDouble(rbS);

        double er = Double.parseDouble(erS);
        double eg = Double.parseDouble(egS);
        double eb = Double.parseDouble(ebS);

        System.out.println("surface : " + rr + "," + rg + "," + rb + "," + er + "," + eg + "," + eb);
        RadSurface aRadSurface = new RadSurface();
        aRadSurface.setRflctnceRGB(rr, rg, rb);
        aRadSurface.setExtnceRGB(er, eg, eb);

        surfaceArrayList.add(aRadSurface);
    }

    public void processPatch(String myLine) {
        StringTokenizer aStringTokenizer = new StringTokenizer(myLine);
        String aSIndex = aStringTokenizer.nextToken();
        int anIndex = Integer.parseInt(aSIndex);
        String aLeftB = aStringTokenizer.nextToken();
        String vs1 = aStringTokenizer.nextToken();
        String vs2 = aStringTokenizer.nextToken();
        String vs3 = aStringTokenizer.nextToken();
        String vs4 = aStringTokenizer.nextToken();
        String aRightB = aStringTokenizer.nextToken();

        System.out.println("patch : " + vs1 + " " + vs2 + " " + vs3 + " " + vs4);
        double v1 = Double.parseDouble(vs1);
        double v2 = Double.parseDouble(vs2);
        double v3 = Double.parseDouble(vs3);
        double v4 = Double.parseDouble(vs4);
        RadPatch aRadPatch = new RadPatch(v1, v2, v3, v4);
        patchArrayList.add(aRadPatch);
    }

    public void processElement(String myLine) {
        StringTokenizer aStringTokenizer = new StringTokenizer(myLine);
        String aSIndex = aStringTokenizer.nextToken();
        int anIndex = Integer.parseInt(aSIndex);
        String aLeftB = aStringTokenizer.nextToken();
        String vs1 = aStringTokenizer.nextToken();
        String vs2 = aStringTokenizer.nextToken();
        String vs3 = aStringTokenizer.nextToken();
        String vs4 = aStringTokenizer.nextToken();
        String aRightB = aStringTokenizer.nextToken();

        System.out.println("Element : " + vs1 + " " + vs2 + " " + vs3 + "," + vs4);
        double v1 = Double.parseDouble(vs1);
        double v2 = Double.parseDouble(vs2);
        double v3 = Double.parseDouble(vs3);
        double v4 = Double.parseDouble(vs4);
        RadElement aRadElement = new RadElement(v1, v2, v3, v4);
        elementArrayList.add(aRadElement);
    }

    public void updteSrfcePatchElmnt() {
        int elmntSize = elementArrayList.size();
        for (int i = 0; i < elmntSize; i++) {
            System.out.println("Adding element "+i+" to patch "+i);
            RadPatch aRadPatch = (RadPatch) patchArrayList.get(i);
            aRadPatch.addElement((RadElement)elementArrayList.get(i));
        }
        int ptchSize = patchArrayList.size();
        for (int i = 0; i < ptchSize; i++) {
            System.out.println("Adding patch "+i+" to surface "+i);
            RadSurface aRadSurface = (RadSurface)surfaceArrayList.get(i);
            aRadSurface.addPatch((RadPatch)patchArrayList.get(i));
        }
    }

    public static void main(String args[]) {
        String fileName = "C:\\...\\...\\...\\COL_CUBE.ENT";
        File2Rad aRad2File = new File2Rad();
        aRad2File.readFile(fileName);
    }
}