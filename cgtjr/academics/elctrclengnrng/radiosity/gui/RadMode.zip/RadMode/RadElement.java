/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cgtjr.academics.elctrclengnrng.radiosity.gui.RadMode;

import java.util.ArrayList;

/**
 *
 * @author cgthomasjr
 */
public class RadElement {

    private double v1;
    private double v2;
    private double v3;
    private double v4;
    int nmbrVertices;
    
    ArrayList theVertexArrayList;

    public RadElement() {
        theVertexArrayList = new ArrayList();
    }

    public RadElement(double myV1, double myV2, double myV3, double myV4) {
        v1 = myV1;
        v2 = myV2;
        v3 = myV3;
        v4 = myV4;
    }

    public RadElement(ArrayList myVertexArrayList) {
        theVertexArrayList = myVertexArrayList;
    }
}
